package com.board.domain;

public class TripVo {

}
